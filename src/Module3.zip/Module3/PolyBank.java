package Module3;

public class PolyBank {

    public void openAccount()
    {
     System.out.println("Opening account from Parent class");
    }
    public void depositMoney()
    {
        System.out.println("Deposit money from Parent class");
    }
    public void transferMoney()
    {
        System.out.println("Transfer money  from Parent class");

    }
    public void withDrawMoney()
    {
        System.out.println("Withdraw  money  from Parent class");

    }

}
