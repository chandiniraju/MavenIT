package Module1;

public class Access1 {
    public String name="xyz";

    public static void add()
    {
        int a=2,b=4;
        int c=a+b;
        System.out.println(c);
    }

    private static void sub()
    {
        int a=2,b=1;
        int c= a-b;
        System.out.println(c);
    }

}
