package Module1;

public class Example1 {

    int x=10;

    public static void main(String[] args)
    {
        int a=2, b=8;
        System.out.println(a+b);
        character();


    }

  public static void character()
  {

      System.out.println("This is example of method");
  }


}
