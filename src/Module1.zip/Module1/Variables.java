package Module1;

public class Variables
{

    public static void main(String[] args)
    {
        byte b=5;                        //declare and initialise byte
        int a=45;                        //declare and initialise integer
        float x=10.5f;                  //declare and initialise decimal number
        double d=234.6;                 //declare and initialise decimal
        char c ='a';                    //declare and initialise character
        String s="To declare variables";  //declare and initialise string
        boolean t=true;                 //declare and initialise boolean

    /* now to print all
    the initialised variables */


        System.out.println("value of byte is  " +b);
        System.out.println("value of int  is  " +a);
        System.out.println("value of float is  " +x);
        System.out.println("value of double is  " +d);
        System.out.println("value of char is  " +c);
        System.out.println("value of string is  " +s);
        System.out.println("value of boolean is  " +t);





    }
}
