package Module5;

public interface Animal1 {
    public void bark();
    public void  drink();


}
