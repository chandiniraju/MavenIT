package Module5;

public interface Animal {

    public void eat();
    public void run();
    public void  sleep();


}
