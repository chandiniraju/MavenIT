package Module5;

public interface Bank1 {

    public void transferMoney();
    public void withDraw();
    public void depositMoney();
}
