package Module5;

public class MathPractice {

    public static void main(String[] args) {

    int x=Math.max(2,3);
    System.out.println(x);
    double m=Math.PI;
    System.out.println(m);
    double y=Math.sqrt(64);
        System.out.println(y);
        double t=Math.random();
        System.out.println(t);


    }


}
