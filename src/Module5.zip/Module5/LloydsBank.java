package Module5;

public abstract class LloydsBank implements Bank1{

    public void transferMoney()
    {
        System.out.println("Lloyds bank transfer money") ;
    }
    public void depositMoney()
    {
        System.out.println("Lloyds bank transfer money") ;
    }
   public abstract void withDraw();

}
