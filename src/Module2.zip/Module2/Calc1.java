package Module2;

public class Calc1

{

 public static void add(int x,int y)
 {
    int z=x+y;
    System.out.println(z);
 }

public static void sub(int m,int n)
{
   int t=m-n;
    System.out.println(t);
}

}
