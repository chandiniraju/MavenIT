package Module4;

public class TescoBank implements Bank{

    public void withDraw()
    {
        System.out.println("Tesco bank withdraw");
    }
    public void depositMoney()
    {
        System.out.println("Tesco bank deposit");
    }
    public void transferMoney()
    {
        System.out.println("Tesco bank transfer");
    }
}
