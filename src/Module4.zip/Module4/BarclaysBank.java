package Module4;

public class BarclaysBank implements Bank{

    public void withDraw()
    {
     System.out.println("Barclays bank withdraw");
    }
    public void depositMoney()
    {
        System.out.println("Barclays bank deposit");
    }
    public void transferMoney()
    {
        System.out.println("Barclays bank transfer");
    }


}
