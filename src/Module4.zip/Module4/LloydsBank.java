package Module4;

public class LloydsBank implements Bank {



    public void withDraw()
    {
        System.out.println("Lloyds bank withdraw");
    }
    public void depositMoney()
    {
        System.out.println("Lloyds bank deposit");
    }
    public void transferMoney()
    {
        System.out.println("Lloyds bank transfer");
    }
}
