package Module4;

public interface Bank {
     public void withDraw();
     public void depositMoney();
     public void transferMoney();

}
